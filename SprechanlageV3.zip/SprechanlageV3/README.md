# Sprechanlage — kleine Web‑Demo

Dies ist eine einfache, lokal editierbare Demo für eine Sprechanlage. Du kannst die MP3s für Gong 1, Gong 2 und Alarm selbst hochladen, Text per TTS sprechen lassen und per Push‑to‑Talk ins System sprechen.

Wichtig:
- Für Geräteselektion (`setSinkId`) und Mikrofonzugriff sollte der Browser über HTTPS oder `http://localhost` laufen (Chrome/Edge empfohlen).

Schnellstart (einfach):

1. Öffne ein Terminal im Ordner und starte einen einfachen Server (z. B. Python):

```bash
python -m http.server 8000
```

2. Öffne `http://localhost:8000` in Chrome/Edge.

3. Lade oben pro Gong eine MP3/Audiodatei hoch. Klicke auf die Buttons `Gong 1` / `Gong 2` / `Alarm`, um die Dateien abzuspielen.

4. Im Einstellungs‑Dialog kannst du Eingabe‑ und Ausgabegerät wählen (falls dein Browser das unterstützt).

Anpassung:
- Dateien sind simpel: `index.html`, `styles.css`, `app.js`. Ändere Texte, Layout oder Funktionalität direkt in diesen Dateien.

Probleme:
- Wenn `setSinkId` nicht funktioniert, unterstütz dein Browser diese Option ggf. nicht oder die Seite läuft nicht über HTTPS/localhost.

Viel Spaß beim Basteln!
